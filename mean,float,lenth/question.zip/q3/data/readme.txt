11 users:(to be used with case1)
cv_11a - example for costs in requirements. 
cv_11b - example for values in requirements.
---
500 users: 
cv_500a - random values between 1 & 10 (inclusive)
cv_500b - ditto
cv_500c - random values between 1 & 5 (inclusive)
cv_500d - ditto

Do create your own cv files for testing.
