# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# p1q3

# All statements should only be in functions. Do not include statements outside functions in this file.
# You may insert additional helper functions into this file if desired. 

def select_advertisers(budget, followers, c, v):
  # TODO: modify this function
  return [0, 1, 2, 3, 4]
