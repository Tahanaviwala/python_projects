# Name: <TODO: replace with your name>
# Section: <TODO: replace with your section>

# p1q2

# All statements should only be in functions. Do not include statements outside functions in this file.
# You may insert additional helper functions into this file if desired. 

def is_stable(n, pref, solution):
  # TODO: modify this function
  return True
